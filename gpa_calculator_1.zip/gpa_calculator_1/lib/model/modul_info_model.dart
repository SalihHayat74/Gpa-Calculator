


class ModuleInfo{
  String moduleTitle;
  double moduleCredits;
  double moduleGradeAttained;

  ModuleInfo({
    required this.moduleTitle,
    required this.moduleCredits,
    required this.moduleGradeAttained
});



}